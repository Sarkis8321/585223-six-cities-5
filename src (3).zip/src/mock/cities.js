export default [
  {
    name: `Paris`,
    coor: [48.85, 2.34],
    id: 10,
  },
  {
    name: `Cologne`,
    coor: [50.93, 6.34],
    id: 20,
  },
  {
    name: `Brussels`,
    coor: [50.85, 4.34],
    id: 30,
  },
  {
    name: `Amsterdam`,
    coor: [52.38, 4.9],
    id: 40,
  },
  {
    name: `Hamburg`,
    coor: [53.57, 10.0],
    id: 50,
  },
  {
    name: `Dusseldorf`,
    coor: [51.22, 6.8],
    id: 60,
  }
];
