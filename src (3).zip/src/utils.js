export const extend = (a, b) => {
    return Object.assign({}, a, b);
  };