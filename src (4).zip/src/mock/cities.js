export default [
  {
    name: `Paris`,
    coord: [48.85, 2.34],
    id: 10,
  },

  {
    name: `Cologne`,
    coord: [50.93, 6.34],
    id: 20,
  },
  {
    name: `Brussels`,
    coord: [50.85, 4.34],
    id: 30,
  },
  {
    name: `Amsterdam`,
    coord: [52.38, 4.9],
    id: 40,
  },
  {
    name: `Hamburg`,
    coord: [53.57, 10.0],
    id: 50,
  },
  {
    name: `Dusseldorf`,
    coord: [51.22, 6.8],
    id: 60,
  }
];
