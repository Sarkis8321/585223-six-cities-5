import offers from "./mock/offers";

const initialState = {
  city: `Amsterdam`,
  offers,
};


export const reducer = (state = initialState) => {

  return state;
};
