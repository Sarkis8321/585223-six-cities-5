// import React, {Component} from 'react';
// import {Map, TileLayer, Marker} from 'react-leaflet';


export default class NeighbourhoodMap {


  render() {
  /*   const position = this.props.geoObjects[0].coord;*/
    return (
    /*   <Map center={position} zoom={12}>
        <TileLayer
          attribution='&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        /> */
      {/*  {
          this.props.geoObjects.map((item) => (

            <Marker position={item.coord} />
          ))
        }*/}
      // </Map>
    );
  }
}

