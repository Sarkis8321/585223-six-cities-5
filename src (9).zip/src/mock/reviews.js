const reviews = [
  {
    id: 1,
    offerId: 1,
    avatar: `img/avatar-max.jpg`,
    autor: `Max`,
    rating: 4,
    date: new Date(2019, 10),
    text: `A quiet cozy and picturesque that hides behind a a river by the unique lightness of Amsterdam. The building is green and from 18th century.`,
  },
  {
    id: 2,
    offerId: 3,
    avatar: `img/avatar-max.jpg`,
    autor: `Serg`,
    rating: 2,
    date: new Date(2020, 11),
    text: `A quiet cozy and picturesque that hides behind a a river by the unique lightness of Amsterdam. The building is green and from 18th century.`,
  },
  {
    id: 3,
    offerId: 4,
    avatar: `img/avatar-max.jpg`,
    autor: `Alex`,
    rating: 3,
    date: new Date(2018, 11),
    text: `A quiet cozy and picturesque that hides behind a a river by the unique lightness of Amsterdam. The building is green and from 18th century.`,
  },
  {
    id: 4,
    offerId: 2,
    avatar: `img/avatar-max.jpg`,
    autor: `Natali`,
    rating: 5,
    date: new Date(2019, 1),
    text: `A quiet cozy and picturesque that hides behind a a river by the unique lightness of Amsterdam. The building is green and from 18th century.`,
  }
];

export default reviews;
